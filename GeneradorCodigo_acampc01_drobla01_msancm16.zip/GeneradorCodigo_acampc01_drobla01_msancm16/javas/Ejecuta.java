

public class Ejecuta {
	
	@SuppressWarnings("unused")
	private Controlador controlador;
	
	public Ejecuta(){
		controlador = new Controlador();
	}
	public static void main(String[] args) {
		new Ejecuta();
	}	
}
