
public class Suma{


	public static int suma(int x, int y){
		return x+y;
	}

}
