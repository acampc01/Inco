
import java.util.ArrayList;
import java.util.List;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Controlador {

	private Interfaz crearOperacion;
	private ArrayList<String> listaMetodos;

	public Controlador(){

		listaMetodos = new ArrayList<String>();

		cargarOperaciones();

		crearOperacion = new Interfaz(this);

	}

	public void cargarOperaciones() {
		List<String> operaciones = new ArrayList<String>();
		
		// ./src en eclipse
		String path = Ejecuta.class.getProtectionDomain().getCodeSource().getLocation().getPath() + "javas";
		File[] files = new File(path).listFiles();
		
		for(File file : files){

			String name = file.getName();
			int pos = name.lastIndexOf(".");
			if(pos > 0)
				name = name.substring(0,pos);

			if(!name.equals("Ejecuta") && !name.equals("Controlador") && !name.equals("Interfaz"))
				operaciones.add(name);

		}
		listaMetodos.addAll(operaciones);
	}

	public List<String> getListaMetodos() {
		return listaMetodos;
	}

	public void setListaMetodos(ArrayList<String> listaMetodos) {
		this.listaMetodos = listaMetodos;
	}

	public void CrearArchivo(String nombre) throws IOException{
		listaMetodos.add(nombre);
		createFile(nombre);
	}

	private void createFile(String nombre) throws IOException{
		String cadena = nombre;
		String primeraLetra = "" + cadena.charAt(0);
		primeraLetra = primeraLetra.toUpperCase();
		String resto = cadena.substring(1);
		resto = resto.toLowerCase();
		cadena = primeraLetra + resto;

		// String nombreArchivo = "./src/" + cadena +".java";
		String nombreArchivo = Ejecuta.class.getProtectionDomain().getCodeSource().getLocation().getPath() + "ArchivosCreados/" + cadena + ".java";
		File archivo = new File(nombreArchivo);

		BufferedWriter bw;
		if(!archivo.exists()) {

			bw = new BufferedWriter(new FileWriter(archivo));
			bw.write("public class " + cadena +  "{\n\n");

			String doble = crearOperacion.getNombreAccion().toLowerCase();
			if(crearOperacion.getNombreAccion().equals("Repetir")){

				if(crearOperacion.getCondicion()){

					bw.write("\tpublic static int "+nombre+"(int "+crearOperacion.getParametro1().toLowerCase()+" , int "+crearOperacion.getParametro2().toLowerCase()+") throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
					if(crearOperacion.getValorCondicion() == 1){
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+"new IgualQue()"+", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					}else if(crearOperacion.getValorCondicion() == 2){
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+"new MenorOIgualQue()"+", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					}else if(crearOperacion.getValorCondicion() == 3){
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+"new MayorOIgualQue()"+", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					}else if(crearOperacion.getValorCondicion() == 4){
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+"new MenorQue()"+", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					}else if(crearOperacion.getValorCondicion() == 5){
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+"new MayorQue()"+", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					}

					bw.write("\t}\n");
					bw.write("\n}");
					bw.close();



				}else {

					bw.write("\tpublic static int "+nombre+"(int "+ crearOperacion.getParametro1().toLowerCase()+" , int " + crearOperacion.getParametro2().toLowerCase()+") throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
					bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"(\""+crearOperacion.getNombreAccionARepetir()+"\", "+crearOperacion.getParametro1().toLowerCase()+", "+crearOperacion.getParametro2().toLowerCase()+");\n");
					bw.write("\t}\n");
					bw.write("\n}");
					bw.close();

				}

			}else{
				if(crearOperacion.getNombreAccion().equals("Suma")){
					if((crearOperacion.getParametro1().toLowerCase().equals("a") && crearOperacion.getParametro1().toLowerCase().equals("-a"))
							&& (crearOperacion.getParametro2().toLowerCase().equals("b") && crearOperacion.getParametro1().toLowerCase().equals("-b")) ){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1().toLowerCase()+","+crearOperacion.getParametro2().toLowerCase()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else if((!crearOperacion.getParametro1().toLowerCase().equals("a") && !crearOperacion.getParametro1().toLowerCase().equals("-a")) 
							&& (crearOperacion.getParametro2().toLowerCase().equals("b") && crearOperacion.getParametro1().toLowerCase().equals("-b")) ){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1()+","+crearOperacion.getParametro2().toLowerCase()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else if((crearOperacion.getParametro1().toLowerCase().equals("a") && crearOperacion.getParametro1().toLowerCase().equals("-a")) 
							&& (!crearOperacion.getParametro2().toLowerCase().equals("b") &&  !crearOperacion.getParametro2().toLowerCase().equals("-b"))){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1().toLowerCase()+","+crearOperacion.getParametro2()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else{
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1()+","+crearOperacion.getParametro2()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}
				}else{
					if((crearOperacion.getParametro1().toLowerCase().equals("a") && crearOperacion.getParametro1().toLowerCase().equals("-a"))
							&& (crearOperacion.getParametro2().toLowerCase().equals("b") && crearOperacion.getParametro1().toLowerCase().equals("-b")) ){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1().toLowerCase()+","+crearOperacion.getParametro2().toLowerCase()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else if((!crearOperacion.getParametro1().toLowerCase().equals("a") && !crearOperacion.getParametro1().toLowerCase().equals("-a")) 
							&& (crearOperacion.getParametro2().toLowerCase().equals("b") && crearOperacion.getParametro1().toLowerCase().equals("-b")) ){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1()+","+crearOperacion.getParametro2().toLowerCase()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else if((crearOperacion.getParametro1().toLowerCase().equals("a") && crearOperacion.getParametro1().toLowerCase().equals("-a")) 
							&& (!crearOperacion.getParametro2().toLowerCase().equals("b") &&  !crearOperacion.getParametro2().toLowerCase().equals("-b"))){
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1().toLowerCase()+","+crearOperacion.getParametro2()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}else{
						bw.write("\tpublic static int "+nombre+"(int a, int b) throws ClassNotFoundException, InstantiationException, IllegalAccessException{\n");
						bw.write("\t\treturn "+crearOperacion.getNombreAccion()+"."+doble+"("+crearOperacion.getParametro1()+","+crearOperacion.getParametro2()+");\n");       
						bw.write("\t}\n");
						bw.write("\n}");
						bw.close();
					}
				}
			}


		}	

	}


}
